# Title
Virtual Box Demo


## Description
This is a demo of the Virtualbox lab that you will be undertaking.  VirtualBox is open source software used in virtualization and allows the user to run multiple operating systems on a single machine. As a cybersecurity professionals, you will use this on your computer to simulate various networks and system stacks for vulnerability analysis and testing.  It is a basic building block in your toolkit.  

<iframe width="640" height="480" src="//www.youtube.com/embed/n1qgQLrDdP8" frameborder="0" allowfullscreen></iframe>
